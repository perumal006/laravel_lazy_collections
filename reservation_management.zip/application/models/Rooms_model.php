<?php
class Rooms_model extends CI_Model
{

	public function get_rooms($data)
    {
        $this->db->select('*');
		$this->db->from('tbl_rooms');

		if(isset($data['rm_type']) && $data['rm_type']!='')
			$this->db->where('rm_type', $data['rm_type']);
		
        return $this->db->get()->result_array();
	}
	
	public function get_booked_status($data)
	{
		$this->db->select('IFNULL(sum(b.tot_rooms_booked), 0) as booked');
		$this->db->from('tbl_rooms a'); 
		$this->db->join('tbl_rooms_reserved b', "b.room_id=a.rm_id AND a.rm_type= '".$data['rm_type']."'", 'LEFT'); 
		$this->db->where("(b.`from_date` BETWEEN '".$data['from_date']."' AND '".$data['to_date']."')  OR  (b.`to_date` BETWEEN '".$data['from_date']."' AND '".$data['to_date']."')");
		return $this->db->get()->row_array();
	}

	public function book_room($ins_arr){
		$this->db->insert('tbl_rooms_reserved', $ins_arr);
        return $this->db->insert_id();	 
	}

	public function booking_reports() {
		$this->db->select('a.room_id, b.rm_type, sum(a.tot_rooms_booked) as booked_count');
		$this->db->from('tbl_rooms_reserved a');
		$this->db->join('tbl_rooms b','b.rm_id = a.room_id', 'left');
		$this->db->where('a.created_on >=', 'DATE_SUB(CURDATE(), INTERVAL 3 MONTH)');
		$this->db->group_by('a.room_id, b.rm_type');
		$this->db->order_by('booked_count', 'DESC');
		return $this->db->get()->result_array();
	}


}
