<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rooms extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->helper('email');
		$this->load->model('rooms_model');
	}

	public function reserve()
	{

		$post = $this->input->post();

		if (is_array($post) && count($post) > 0) {

			// Set the validation rule
			$this->form_validation->set_rules('room_type', 'room type', 'trim|required');
			$this->form_validation->set_rules('from_date', 'check-in date', 'trim|required');
			$this->form_validation->set_rules('to_date', 'check-out date', 'trim|required');
			$this->form_validation->set_rules('no_of_rooms', 'no of room', 'trim|required|numeric');
			$this->form_validation->set_rules('name', 'name', 'trim|required');
			$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
			$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|numeric');

			if ($this->form_validation->run() == FALSE) {

				// Field validation failed
				$err_arr = array_values($this->form_validation->error_array());
				$res_arr = array('success' => 'false', 'error' => 'Field validation error', 'msg' => $err_arr[0]);

			} else {

				// Collect the post data
				$rm_type = trim($this->input->post('room_type'));
				$from_date = trim($this->input->post('from_date'));
				$to_date = trim($this->input->post('to_date'));
				$rooms_requested = trim($this->input->post('no_of_rooms'));
				$cust_name = trim($this->input->post('name'));
				$cust_email = trim($this->input->post('email'));
				$cust_mobile = trim($this->input->post('mobile'));

				// Get the booking status
				$res_rooms = $this->rooms_model->get_rooms(array('rm_type'=>$rm_type));
				$rms_booked = $this->rooms_model->get_booked_status(array('rm_type'=>$rm_type, 'from_date'=>$from_date, 'to_date'=>$to_date));

				// Check the room  
				if(is_array($res_rooms) && count($res_rooms)>0) {

					$rooms_available = $res_rooms[0]['rm_tot_available'] - $rms_booked['booked'];

					// Verify booking
					if($rooms_requested <= $rooms_available) {

						$data = array(
							'room_id' => $res_rooms[0]['rm_id'],
							'from_date' => $from_date,
							'to_date' => $to_date,
							'tot_rooms_booked' => $rooms_requested,
							'cust_name' => $cust_name,
							'cust_email' => $cust_email,
							'cust_mobile' => $cust_mobile,
							'created_on' => date('Y-m-d G:i:s')
						);
						
						// Book the room
						$result = $this->rooms_model->book_room($data);
	
						if ($result) {
							$res_arr = array('success' => 'true', 'msg' => 'Reserved successfully', 'booking_id' => $result);
						} else {
							$res_arr = array('success' => 'false', 'error' => 'Booking error','msg' => 'Resrevation failed');
						}


					} else {
						$res_arr = array('success' => 'false', 'error' => 'Room availablity error', 'msg' => 'Oops! room not available');
					}

				} else {
					$res_arr = array('success' => 'false', 'error' => 'Room type error', 'msg' => 'Oops! this room type is not available');
				}

			}
		} else {
			$res_arr = array('success' => 'false', 'error' => 'Input error', 'msg' => 'Invalid or no post data');
		}

		header('Content-Type: application/json');
		echo json_encode($res_arr);
	}

	public function get_reports() {
		$res_arr = $this->rooms_model->booking_reports();
		header('Content-Type: application/json');
		echo json_encode($res_arr);
	}

	
}
