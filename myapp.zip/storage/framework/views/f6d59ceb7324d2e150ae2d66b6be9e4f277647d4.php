<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

</head>

<body>
    <div class="container">

        <h2>Laravel</h2>

        <div class="alert alert-info">         
           <p> <strong>Task: </strong>Import the bulk data by using the fields (ID, First name, Last Name, Email, Mobile no, Address) minimum 1000 datas.</p>
           <p> <strong>Souce file: </strong>storage/csv/user_data.csv</p>
           <p> <strong>Target database: </strong>Laravel_task</p>
           <p> <strong>Target table: </strong>users</p>
           <p> <strong>Approach: </strong>Lazy Collections </p>
            <div style="margin-top: 10px;"><a href="<?php echo url('import') ?>" class="btn btn-large btn-primary">Click to Import</a></div>
        </div>

        <?php if(isset($status)): ?>    
            <div class="alert alert-success">
            <p> <strong>Status: </strong><?php echo e($status); ?></p>
            <p> <strong>Message: </strong><?php echo e($message); ?></p>
            <p> <strong>Info: </strong><?php echo e($info); ?></p>
            </div>
        <?php endif; ?>
           
       


    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\myapp\resources\views/task.blade.php ENDPATH**/ ?>