<?php

namespace App\Http\Controllers;

use App\Users;
use Illuminate\Support\LazyCollection;

class UsersController extends Controller
{

    function import()
    {

        LazyCollection::make(function () {
            $filePath = storage_path('csv\users_data.csv');
            $handle = fopen($filePath, 'r');
            while ($line = fgetcsv($handle)) {
                yield $line;
            }
        })
            ->chunk(1000) //split in chunk to reduce the number of queries
            ->each(function ($lines) {
                $list = [];
                foreach ($lines as $line) {
                    if (isset($line[1])) {
                        $list[] = [
                            'first_name' => $line[0],
                            'last_name' => $line[1],
                            'email' => $line[2],
                            'mobile' => $line[3],
                            'address' => $line[4]
                        ];
                    }
                }
                // insert 1000 rows in one shot
                Users::insert($list);
            });

        /* display memory usage */
        $data_count = Users::count(); 
        $memory_usage = number_format(memory_get_peak_usage() / 1048576, 2) . ' MB';

        $data = array(
            'status' => 'Success',
            'message' => 'User table count is '.$data_count,
            'info' => 'Peak memory usage is'. $memory_usage
        );

        return view('task')->with($data);
    }
}
